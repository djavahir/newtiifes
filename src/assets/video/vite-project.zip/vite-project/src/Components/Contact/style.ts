import styled from "styled-components";

const Wrapper=styled.div`
width: 100%;
padding:100px 0;
background: black;
display: flex;
align-items: center;
justify-content: center;
`

const Container=styled.div`
max-width: 1480px;
width: 100%;
display: flex;
flex-direction: column;
gap: 30px;
`
const Wrap=styled.div`
display: flex;
justify-content: space-between;
width: 100%;
height: 100%;
`
const Box=styled.div`
display: flex;
flex-direction: column;
gap: 10px;
`
const P=styled.a`
color: white;
display: flex;
gap: 10px;
font-size: 18px;
&:hover{
    color: #EBAD2D !important;
    transition:2s ;
    cursor: pointer;
}
`
const Img =styled.img`
width: 24px;
height: 24px;
`

export {Wrapper,Wrap,P,Box,Container,Img}