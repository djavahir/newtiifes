import { Lines } from "./style"

const Line = () => {
  return (
    <Lines></Lines>
  )
}

export default Line