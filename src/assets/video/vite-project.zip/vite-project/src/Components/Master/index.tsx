import { Buton, Container, Wrapper } from "./style";
import { DownloadOutlined } from '@ant-design/icons';
import ProgInfo from "../ProgInfo"



const Master = () => {
 
  return (
    <Wrapper>
      <Container>
        <div style={{display:"flex", justifyContent:"space-between",alignItems:"center"}}>
         <h1 style={{ color: "white", fontSize: "40px", lineHeight: "48px" }}>Мастер-класс</h1>
         <Buton type="primary" icon={<DownloadOutlined />}>Скачать</Buton>
       </div>                                 
        <div style={{display:"flex",flexWrap:"wrap",width:"100%",gap:"60px"}}>
          <ProgInfo/>
          <ProgInfo/>
          <ProgInfo/>
          <ProgInfo/>
          <ProgInfo/>
          <ProgInfo/>
        </div>
      </Container>
    </Wrapper>
  );
};

export default Master;
